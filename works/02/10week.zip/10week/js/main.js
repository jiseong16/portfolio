$(function(){

    // sc_visual   

    gsap.to(".sc_visual .wrap", {
        y: -30,
        opacity:1,
        stagger: {
            from: "random",
            amount: 3,   
        }
    });

    gsap.from(".sc_visual .book", {
        delay:4.5,
        opacity:0,
    });


    // sc_creative

    const textmoiton = gsap.timeline({
        defaults:{
            duration:1,
        },
        scrollTrigger:{
            trigger:".sc_creative .line02",
            start:"bottom 100%",
            end:"bottom 95%",
            markers:"true",
            scrub:"0.5",
            // pin:"",
        }
    })

    textmoiton.addLabel('label1')
    .to('.sc_creative .line01',{xPercent:-60},'label1')
    .to('.sc_creative .line02',{xPercent:30},'label1')
    .to('.sc_creative .line03',{xPercent:70},'label1')
    



    const fixmotion = gsap.timeline({
        scrollTrigger:{
            trigger:".sc_creative",
            start:"top top",  
            end:"+=3000", 
            markers:true,  
            scrub:0.5,
            pin:true,           
        },
    })

    fixmotion.to('.sc_creative .img_wrap',{y:-2200})





     const fixmotion2 = gsap.timeline({
        defaults:{
            delay:0.1
        },
        scrollTrigger:{
            trigger:".sc_nature",
            start:"top top",
            end:"+=8000",
            markers:true,
            scrub:0.5,
            pin:true,
        }


    })

    fixmotion2.addLabel('label1')
    .to('.sc_nature .wrap',{x:-7500},'label1')



})