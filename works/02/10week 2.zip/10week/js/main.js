$(function(){

    // sc_visual   

    gsap.from(".sc_visual .wrap", {
        y: 30,
        opacity:0,
        stagger: {
            from: "random",
            amount: 2,   
        }
    });

    gsap.from(".sc_visual .book", {
        delay:4.5,
        opacity:0,
    });


    // sc_creative

    const textmoiton = gsap.timeline({
        defaults:{
            duration:1,
        },
    })

    textmoiton.addLabel('label1')
    .to('.sc_creative .line01',{xPercent:-30},'label1')
    .to('.sc_creative .line02',{xPercent:15},'label1')
    .to('.sc_creative .line03',{xPercent:55},'label1')
    


    ScrollTrigger.create({
        animation: textmoiton,
        trigger:".sc_creative .line02",
        start:"top 100%",
        end:"bottom 100%",
        // markers:true,
        // scrub:"0.5",
        // pin:"",
        onLeaveBack:()=>{
            textmoiton.reverse(); 
        },

    })




    const fixmotion = gsap.timeline({})
    
    fixmotion.to('.sc_creative .img_wrap',{y:-2200})


    // const fixmotion_1 = gsap.timeline({})
    // fixmotion_1.set('.sc_creative .img_wrap',{opacity:0})
    // .to('.sc_creative .img_wrap',{opacity:1,duration:1})
        
    
    
    ScrollTrigger.create({
        animation:fixmotion,
        trigger:".sc_creative",
        start:"top top",  
        end:"+=3000", 
        // markers:true,  
        scrub:0.5,
        pin:true,           
    }),






    // ScrollTrigger.create({
    //     animation:fixmotion_1,
    //     trigger:".sc_creative",
    //     start:"top top",  
    //     // end:"+=3000", 
    //     // markers:true,  
    //     // scrub:0.5,
    //     // pin:true,           
    // })
    










    ScrollTrigger.create({
        trigger:".sc_nature",
        start:"top 40%",
        markers:true,
        onEnter:()=>{
            $('body').addClass('black')
        },
        onLeaveBack:()=>{
            $('body').removeClass('black')
        }
    })

  






     const fixmotion2 = gsap.timeline({
        defaults:{
            delay:0.5
        },
        scrollTrigger:{
            trigger:".sc_nature",
            start:"top top",
            end:"+=2000%",
            // markers:true,
            scrub:0.5,
            pin:true,
            onLeave:()=>{
                $('body').removeClass('black')
            }
        }


    })

    fixmotion2.to('.sc_nature .wrap',{
        xPercent:-100,
        x:'100vw',
        duration:9.5
    })
    .to('.sc_nature .wrap',{duration:0.5})




    const natureTxt01 = new SplitType('.sc_nature .nature01 .txt', { types: 'words, chars', });
    
    const txtMotion01  = gsap.fromTo(natureTxt01.chars,{
        opacity:0,
        yPercent:100

    },{
        opacity:1,
        stagger:0.03,
        yPercent:0,

    })  
    txtMotion01.pause();


    ScrollTrigger.create({
        trigger:".nature01",
        start:"top top",
        onEnter:()=>{
            txtMotion01.restart();
        },
    })


    // const natureAll = $('.sc_nature .wrap').outerWidth();
    // const nature03 = $('.sc_nature .wrap .nature03').offset().left;
    // const result = nature03/natureAll*100;
    // a = result2000/100;
    // console.log(a);



    const txtMotion02  = gsap.fromTo('.sc_nature .wrap .nature03 h3 span',{
        opacity:0,
        yPercent:100

    },{
        opacity:1,
        stagger:0.1,
        yPercent:0,
    })  
    txtMotion02.pause();

    ScrollTrigger.create({
        trigger:".nature01",
        start:"+500%",
        onEnter:()=>{
            txtMotion02.play();
        },
    })


    $('.img_event').each(function(index,item){

        const fixmotion_1 = gsap.timeline({})
        fixmotion_1.set(item,{opacity:0})
        .to(item,{opacity:1,duration:1})
        

        ScrollTrigger.create({
            animation:fixmotion_1,
            trigger:item,
            start:"top 60%",  
            // markers:true,  

            onEnter:()=>{
                $(item).addClass('on')
            }

        })
    })

})