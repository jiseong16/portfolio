$(function(){


    $(window).scroll(function(){

        curr = $(window).scrollTop();

        if(curr > 100){
            $('header').addClass('on')
        }else{
            $('header').removeClass('on')
        }

    });

    $('header .cart').click(function(e){
        e.preventDefault();

        $('.side_cate').addClass('on');
        $('body').addClass('hidden')
        $('header .dimm').addClass('on')
    })

    $('.side_cate .close,.dimm').click(function(e){
        e.preventDefault();

        $('.side_cate').removeClass('on');
        $('body').removeClass('hidden')
        $('header .dimm').removeClass('on')
    })
    


})