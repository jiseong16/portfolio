$(function(){

    $('.sc_place .tab_nav a').click(function(e){
        e.preventDefault();

        target = $(this).attr('href')

        $(this).addClass('on').siblings().removeClass('on')

        $(target).addClass('on').siblings().removeClass('on');

        if($('#studio').hasClass('on')){
            $('.sc_place').addClass('on')
            $('.sc_place .mark svg').addClass('on')

        }else{
            $('.sc_place').removeClass('on')
            $('.sc_place .mark svg').removeClass('on')
        }

        
    
    })

    var video_slide = new Swiper(".video_slide", {
        pagination: {
          el: ".swiper-pagination",
          type: "fraction",
        },
        // navigation: {
        //   nextEl: ".swiper-button-next",
        //   prevEl: ".swiper-button-prev",
        // },
      });


})